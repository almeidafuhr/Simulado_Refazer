﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AvaliacaoCSharp
{
    public enum StatusConvenio
    {
        Cadastrado = 1,
        Deferido = 2,
        Suspenso = 3
    }
}
