﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AvaliacaoCSharp
{
    public class Convenio
    {
        public string Cnpj;
        public string RazaoSocial;
        public int QuantidadeEmpregados;
        public StatusConvenio Status;
        public DateTime DtAtuStatus;

        public Convenio() { }
        public Convenio(string cnpj, string razaoSocial, int quantidadeEmpregados, StatusConvenio status, DateTime dataStatus)
        {
            Cnpj = Cnpj;
            RazaoSocial = razaoSocial;
            QuantidadeEmpregados = quantidadeEmpregados;
            Status = status;
            DtAtuStatus = dataStatus;
        }

    }
}
