﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AvaliacaoCSharp
{
    public class Retorno
    {
        public int Codigo;
        public string Mensagem;
        //public T Dados;

        public Retorno (int codigo, string mensagem)  //T dados
        {
            Codigo = codigo;
            Mensagem = mensagem;
            //Dados = dados;
        }
    }
}
