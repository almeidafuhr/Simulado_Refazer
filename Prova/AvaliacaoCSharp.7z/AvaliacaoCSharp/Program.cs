﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AvaliacaoCSharp
{
    class Program
    {
        private static CadastroConvenio cadastroConvenio = new CadastroConvenio();

        static void Main(string[] args)
        {
            gerarMenu();
        }

        private static void gerarMenu()
        {
            Int16 opcao = 0;
            do
            {
                Console.WriteLine("Cadastro de convênios para crédito consignado");
                Console.WriteLine("---------------------------------------------");
                Console.WriteLine("");
                Console.WriteLine($"Total de Convênios: ");
                Console.WriteLine("");
                Console.WriteLine("1.Adicionar convênio");
                Console.WriteLine("2.Remover convênio");
                Console.WriteLine("3.Listar convênios");
                Console.WriteLine("4.Salvar convênios");
                Console.WriteLine("5.Sair");
                Console.WriteLine("");
                Console.Write("Informe a opção desejada: ");
                String entrada = Console.ReadLine().Trim();
                Console.WriteLine("");

                try
                {
                    opcao = Convert.ToInt16(entrada);
                }
                catch (Exception e)
                {
                    opcao = 0;
                }

                if (opcao >= 1 && opcao <= 4)
                {
                    executarEscolha(opcao);
                }
                else if (opcao != 5)
                {
                    Console.WriteLine("Opção iválida!");
                    limpar();
                }
            } while (opcao != 5);
            
        }

        static void limpar()
        {
            Console.WriteLine();
            Console.WriteLine("<<PRESSIONE PARA CONTINUAR>>");
            Console.ReadKey();
            Console.Clear();
        }

        static void executarEscolha(Int16 opcao)
        {
            Retorno retCnpj, retRazaoSocial, retQtdEmpregados, retStatus, retAtuData, retorno;
            Convenio convenio = new Convenio();

            switch (opcao)
            {
                case 1:

                    Console.Write("Informe o CNPJ: ");
                    string cnpj = Console.ReadLine().Trim();

                    Console.Write("Informe a Razão Social: ");
                    string razaoSocial = Console.ReadLine().Trim();

                    Console.Write("Informe a quantidade de empregados: ");
                    string qtdEmpregados = Console.ReadLine().Trim();

                    Console.Write("Informe o status: [1 - Cadastrado 2 - Deferido 3 - Suspenso] ");
                    string status = Console.ReadLine().Trim();

                    Console.Write("Informe a data de atualização do status : ");
                    string dataAtualizacao = Console.ReadLine().Trim();

                    break;
                case 2:
                    Console.Write("Informe o CNPJ: ");
                    cnpj = Console.ReadLine().Trim();
                    
                    
                    limpar();     
                    break;
                case 3:
                    Retorno ret = cadastroConvenio.ListarConvenios();
                    Console.WriteLine($"{ret.Codigo} - {ret.Mensagem}");
                    limpar();
                    break;
                case 4:

                    limpar();
                    break;
                case 5:
                    break;
            }
        }
    }
}
