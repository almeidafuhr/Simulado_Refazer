﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AvaliacaoCSharp
{
    class CadastroConvenio
    {
        private string caminhoBancoDados;
        private List<Convenio> listaConvenios = new List<Convenio>();

        public CadastroConvenio() { }
        public CadastroConvenio(string caminhoBancoDados)  // VERIFICAR
        {
            this.caminhoBancoDados = caminhoBancoDados;
        }


        public Retorno AdicionarConvenio(string cnpj, string razaoSocial, string qtdEmpregados, StatusConvenio status, string dataAtu)  //TIPO RETORNO
        {
            //Retorno retCnpj, retRazaoSocial, retQtdEmpregados, retStatus, retAtuStatus;
            Convenio convenio = new Convenio();
            convenio.Cnpj = cnpj;
            convenio.RazaoSocial = razaoSocial;
            convenio.QuantidadeEmpregados = int.Parse(qtdEmpregados);
            convenio.Status = status;
            convenio.DtAtuStatus = DateTime.Parse(dataAtu);

            listaConvenios.Add(convenio);
            return new Retorno(0, "Operação realizada com sucesso."); 
        }

        
        /*
        public Retorno RemoverConvenio(string cnpj)  //TIPO RETORNO
        {
            Retorno retCnpj;
            do
            {
                Console.Write("Entre com o CNPJ: ");
                cnpj = Console.ReadLine();
            } while (retCnpj.Codigo != 0);
            
            if (retCnpj.Codigo == 0)
            {
                foreach (var lp in listaConvenios)
                {
                    if (lp.Cnpj.Equals(cnpj))
                    {
                        listaConvenios.Remove(lp);
                        return new Retorno(0, "Sucesso");
                    }
                }
            }
            return new Retorno(19, "<<Não foi possível remover>>");
        }
        */

        public Retorno ListarConvenios()  
        {
            if (listaConvenios.Count > 0)
            {
                var listaOrdenada = listaConvenios.OrderBy(l => l.Cnpj);
                foreach (var lista in listaOrdenada)
                {
                    Console.WriteLine($"{lista.Cnpj} {lista.RazaoSocial} {lista.QuantidadeEmpregados} {lista.DtAtuStatus} {lista.DtAtuStatus.ToShortDateString()}");
                }
                return new Retorno(0, "Sucesso");
            }
            else
                return new Retorno(30, "Nenhum registro encontrado");

        }

        public void SalvarConvenios()  
        {

        }

        private Retorno validarCnpjCompleto(string entrada)
        {
            String regex = "^[1-9]\\d{2,13}$";
            if (System.Text.RegularExpressions.Regex.IsMatch(entrada, regex))
            {
                foreach (var convenio in listaConvenios)
                {
                    if (convenio.Cnpj.Equals(entrada))
                    {
                        return new Retorno(11, "Já existe um convênio com esse CNPJ.");
                    }
                }
                return new Retorno(0, "Operação realizada com sucesso.");
            }
            else
            {
                return new Retorno(10, "O CNPJ informado é inválido.");
            }
        }

        private Retorno EncontrarCnpj(string entrada)
        {
            foreach (var convenio in listaConvenios)
            {
                if (convenio.Cnpj.Equals(entrada))
                {
                    return new Retorno(11, "Já existe um convênio com esse CNPJ.");
                }
            }
            return new Retorno(0, "Operação realizada com sucesso.");
        }

        private Retorno validarRazaoSocial(string entrada)
        {
            if(entrada.Count() > 3)
            {
                return new Retorno(0, "Operação realizada com sucesso.");
            }
            else
            {
                return new Retorno(12, "A razão social deve ter pelo menos 3 caracteres");
            }
        }

        private Retorno validarEmpregados(string entrada)
        {
            try
            {
                int empregador = 0;
                if (int.TryParse(entrada, out empregador))
                {
                    if (empregador <= 0)
                    {
                        return new Retorno(14, "A quantidade de empregados deve ser maior que 0");
                    }
                }
            }
            catch(FormatException ex)
            {
                return new Retorno(13, "A quantidade de empregados informada é inválida");
            }
            return new Retorno(0, "Operação realizada com sucesso.");
        }

        private Retorno validarStatus(StatusConvenio status, string entrada)
        {
            
            switch (status)
            {
                case StatusConvenio.Cadastrado:
                    return new Retorno(0, "Operação realizada com sucesso.");
                case StatusConvenio.Deferido:
                    return new Retorno(0, "Operação realizada com sucesso.");
                case StatusConvenio.Suspenso:
                    return new Retorno(0, "Operação realizada com sucesso.");
                default:
                    return new Retorno(15, "O status é inválido");
            }
        }

        private Retorno validarData(string entrada)
        {
            DateTime data;
            DateTime hoje = DateTime.Now;
            string dataPattern = "dd/MM/yyyy";

            if (DateTime.TryParseExact(entrada, dataPattern, null, System.Globalization.DateTimeStyles.None, out data))
            {
                if (data > hoje)
                    return new Retorno(17, "A data de atualização do status não pode ser uma data futura");
            }
            else
                return new Retorno(16, "A data de atualização do status é inválida");
            return new Retorno(0, "Sucesso");
        }

        


    }
}
