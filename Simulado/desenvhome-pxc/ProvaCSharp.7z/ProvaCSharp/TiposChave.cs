﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bergs.ProvaCSharp
{
    public enum TiposChave
    {
        Telefone = 1,
        Cpf = 2
    }
}
